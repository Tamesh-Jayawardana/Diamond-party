{
  "icons": [
  	"bag-outline                 ",
	"cart-outline                ",
	"bag                         ",
	"handbag                     ",
	"shopping-cart               ",
	"bag2                        ",
	"shopping-cart-solid         ",
	"basket-outline              ",
	"shopping-basket-solid       ",
	"heart                       ",
	"heart2                      ",
	"heart-solid                 ",
	"heart-outline               ",
	"ios-heart-outline           ",
	"shuffle                     ",
	"refresh                     ",
	"ios-shuffle                 ",
	"ios-shuffle-strong          ",
	"repeat-outline              ",
	"sync-alt-solid              ",
	"star2                       ",
	"star-solid                  ",
	"star-half-alt-solid         ",
	"search                      ",
	"magnifier                   ",
	"search2                     ",
	"loupe                       ",
	"search1                     ",
	"eye-outline                 ",
	"eye                         ",
	"look                        ",
	"eye2                        ",
	"bars-solid                  ",
	"menu-outline                ",
	"navicon-round               ",
	"grid-outline                ",
	"grid                        ",
	"grid2                       ",
	"apps-outline                ",
	"apps-sharp                  ",
	"list                        ",
	"list-outline                ",
	"list-solid                  ",
	"arrow-down                  ",
	"arrow-left                  ",
	"arrow-right                 ",
	"arrow-up                    ",
	"logo-facebook               ",
	"logo-google                 ",
	"logo-pinterest              ",
	"logo-twitter                ",
	"logo-youtube                ",
	"logo-instagram              ",
	"logo-linkedin               ",
	"logo-rss                    ",
	"logo-twitch                 ",
	"0-facebook2                 ",
	"1-twitter2                  ",
	"2-youtube2                  ",
	"3-dribbble                  ",
	"4-facebook-f                ",
	"5-google-plus-g             ",
	"6-pinterest-p               ",
	"close-outline               ",
	"close-circle                ",
	"close-circle-outline        ",
	"person-outline              ",
	"person-circle-outline       ",
	"user                        ",
	"user-circle                 ",
	"call-outline                ",
	"call-sharp                  ",
	"headphones                  ",
	"headphones-mic              ",
	"headphones2                 ",
	"phone-volume-solid          ",
	"phone-call                  ",
	"headset-outline             ",
	"settings-outline            ",
	"settings                    ",
	"shipping-fast-solid         ",
	"truck-solid                 ",
	"ship-solid                  ",
	"boat-outline                ",
	"rocket                      ",
	"rocket-outline              ",
	"location-pin                ",
	"map-marked-alt-solid        ",
	"location-outline            ",
	"mail-outline                ",
	"mail-open-outline           ",
	"globe-solid                 ",
	"globe-alt                   ",
	"scan-outline                ",
	"expand-outline              ",
	"checkmark                   ",
	"card-outline                ",
	"credit-card-solid           ",
	"money-bill-wave-solid       ",
	"cash-outline                ",
	"gift-outline                ",
	"gift-solid                  ",
	"gifts-solid                 ",
	"ribbon-outline              ",
	"time-outline                ",
	"help-buoy-outline           ",
	"exchange-1                  ",
	"call-center-24-7            ",
	"headphone-24-7              ",
	"credit-card-secure1         ",
	"payment-security            "
	]
}